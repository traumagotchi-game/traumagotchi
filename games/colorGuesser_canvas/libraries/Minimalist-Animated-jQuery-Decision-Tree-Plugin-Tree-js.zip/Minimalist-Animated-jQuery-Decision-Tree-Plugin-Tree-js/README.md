# Qestion based Decision Tree jQuery Plugin

## Installation

### Bower Installation (Preferred)

```
bower install jquery-decision-tree
```